import java.util.Scanner;

public class CheckPrime {

/* A prime number is a natural number greater than 1 
 * that has no positive divisors other than 1 and itself.
 */
	public static void main(String[] args) {
		
		int number;
		
		@SuppressWarnings("resource")
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter a number : ");
		number = s.nextInt();
		
		RunnableThread runnable = new RunnableThread(number); /*call runnable interface*/
		Thread t2 = new Thread(runnable);
		t2.start(); /*Thread started for runnable*/
	}
}
