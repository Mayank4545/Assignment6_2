
public class RunnableThread implements Runnable{

	int number;
	char flag;
	int mid;

	public RunnableThread(int number) {
		super();
		this.number = number;
	}

	@Override
	public void run() {
		mid = number/2;
		for (int i = 2; i < mid; i++) {
			if ((number % i) == 0) {
				flag = 'X';
				break;
			}			
		}

		if (flag == 'X' || number == 1) { /*1 is not a prime number */
			System.out.println(number + " is not a prime number.");
		}else{
			System.out.println(number + " is a prime number");
		}
	}
}
